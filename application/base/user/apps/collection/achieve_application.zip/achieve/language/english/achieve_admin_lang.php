<?php
$lang["achieve"] = "Achieve";
$lang["general"] = "General";
$lang["enable_app"] = "Enable App";
$lang["if_is_enabled_achieve"] = "You will be able to see it in the Plans page";
$lang["if_is_enabled_achieve_plan"] = "If is enabled the Achieve app will be available for this plan";
$lang["enable_url_download"] = "Enable Images Url Download";
$lang["enable_url_download_description"] = "If is enabled users will be able to download images from url.";
