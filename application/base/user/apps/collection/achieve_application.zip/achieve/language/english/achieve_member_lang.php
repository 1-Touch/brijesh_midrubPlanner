<?php
$lang["achieve"] = "Achieve";
$lang["achieve_allow"] = "Allow Achieve";
$lang["achieve_allow_if_enabled"] = "If is allowed, Team's member will be able to see the Achieve.";